package com.ismailhakkiaydin.football.ui.fixture.detail

import androidx.fragment.app.FragmentManager

class FixtureDetailPagerAdapter(fm:FragmentManager):BasePagerAdapter(fm){

}
